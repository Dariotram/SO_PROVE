#define IN_USO 2
#define OCCUPATO 1
#define LIBERO 0
#define NUM_PROCESSI 20
#define NUM_CONDITION 2
#define DIM 100

#define OK_FORNITURA 0
#define OK_CLIENTE 1

typedef struct{
	unsigned int id_fornitore;
	unsigned int stato;
}scaffale;


void Fornitore(scaffale*,Monitor*,int*); 
void Cliente(scaffale*,Monitor*,int*);
void FineFornitore(scaffale*,Monitor*,int,int*);
void FineCliente(Monitor*,scaffale*,int,int*);
int InizioCliente(Monitor*,scaffale*,int*);
int InizioFornitore(scaffale*,Monitor*,int*);
