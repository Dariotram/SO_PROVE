
#include "../monitor/monitor.h"
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/sem.h>
#include <sys/shm.h>

int main(){
	pid_t pid;
	int id_shm,id_shm2,status;
	int * livello_scorte;
	key_t chiave_shm;
	chiave_shm=IPC_PRIVATE;
	scaffale* magazzino;
	Monitor M;
	init_monitor(&M,NUM_CONDITION);
	
	
	sleep(2);
	id_shm2=shmget(chiave_shm,sizeof(scaffale)*DIM,IPC_CREAT|0664);
	magazzino=(scaffale*)(shmat(id_shm2,0,0) );
	id_shm=shmget(chiave_shm,sizeof(int),IPC_CREAT|0664);
	livello_scorte=(int*)(shmat(id_shm,0,0) );
	(*livello_scorte)=0;
	for(int i=0;i<DIM;i++){
		magazzino[i].stato=LIBERO;
	}

	for(int i=0;i<NUM_PROCESSI;i++){
		pid=fork();
		if(pid==0){
			if(i%2==0){
				printf("Sono un fornitore <%d> \n",getpid() );
				for(int i=0;i<15;i++){
				Fornitore(magazzino,&M,livello_scorte);
				}
			}else{
				printf("Sono un cliente <%d> \n",getpid() );
				for(int i=0;i<15;i++){
				Cliente(magazzino,&M,livello_scorte);
				}
			}_exit(0);
		}	
	}

	for(int i=0;i<NUM_PROCESSI;i++){
		pid=wait(&status);
		if(pid==-1)
			perror("errore");
		else
			printf("Terminato il processo <%d> con stato: %d \n",pid,status );

	}
remove_monitor(&M);
shmctl(id_shm,IPC_RMID,0);
shmctl(id_shm2,IPC_RMID,0);
}
