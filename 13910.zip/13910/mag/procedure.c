
#include "../monitor/monitor.h"
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/sem.h>

int InizioFornitore(scaffale* mag, Monitor* M,int* livello_scorte){
	int i=0;	
	enter_monitor(M);
	if((*livello_scorte)==DIM){
		wait_condition(M,OK_FORNITURA);
	}
	while( !(mag[i].stato==LIBERO) )
		i++;
	mag[i].stato=IN_USO;
	sleep(1);
	leave_monitor(M);
	return i;
	
}

void FineFornitore(scaffale* mag,Monitor* M,int indice,int* livello_scorte){
	enter_monitor(M);
	mag[indice].stato=OCCUPATO;
	mag[indice].id_fornitore=getpid();
	(*livello_scorte)=++(*livello_scorte);
	signal_condition(M,OK_CLIENTE);
	leave_monitor(M);
}
void Fornitore(scaffale* mag,Monitor* M,int* scorte){
	int indice=InizioFornitore(mag,M,scorte);
	//printf("Il processo <%d> rifornisce lo scaffale #%d \n",getpid(), indice);
	sleep(2);
	FineFornitore(mag,M,indice,scorte);
}

void Cliente(scaffale* mag,Monitor* M,int* livello_scorte){
	int indice=InizioCliente(M,mag,livello_scorte);	
	
	printf("Il cliente <%d> ha acquistato da: <%d> , scaffale <%d> \n",getpid(),mag[indice].id_fornitore, indice );
	sleep(2);
	FineCliente(M,mag,indice,livello_scorte);
}

void FineCliente(Monitor* M,scaffale* mag,int i,int* scorte){
	//sleep(2);
	enter_monitor(M);
	mag[i].id_fornitore=0;
	(*scorte)=(*scorte)-1;
	//printf("Il cliente <%d> riduce scorte a <%d> \n",getpid(),(*scorte) );
	mag[i].stato=LIBERO;
	signal_condition(M,OK_FORNITURA);
	leave_monitor(M);
}
int InizioCliente(Monitor* M,scaffale* mag,int* scorte){
	int i=0;
	enter_monitor(M);
	//printf("Il cliente <%d> controlla le scorte che sono<%d> \n",getpid(),(*scorte) );
	if((*scorte)<=0){
		wait_condition(M,OK_CLIENTE);
	}
	while( mag[i].stato!=OCCUPATO )
		i++;
	mag[i].stato=IN_USO;
	leave_monitor(M);
	return i;
}

