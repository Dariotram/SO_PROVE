#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "header.h"

int main(){
pid_t pid;
int status,queueB,queueS;
key_t chiave_queue;
int totale=NUM_CLIENT + NUM_SERVER +1;
chiave_queue=IPC_PRIVATE;
queueB=msgget(chiave_queue,IPC_CREAT|0664);// del balancer
queueS=msgget(chiave_queue,IPC_CREAT|0664);//del server 
contatore=2;
pid=fork();
if(pid==0){
		printf("Sono il Balancer");
		Balancer(queueB,queueS);
		_exit(0);
}

for(int i=0;i<3;i++){
	pid=fork();
	if(pid==0){
		printf("Sono il Server #%d \n",i+1);
		Server(queueS,(i+1));
		_exit(0);
	}
}

for(int i=0;i<8;i++){
	pid=fork();
	if(pid==0){
		printf("<%d> Sono il Client #%d \n",getpid(),i );
		sleep(5);
		Client(queueB);	
		_exit(0);
	}
}

for(int k=0;k<12;k++){
	pid=wait(&status);
	if(pid==-1)
		perror("errore");
	else
		printf("Terminato il filgio <%d> , con stato <%d> \n",pid,status);
}

msgctl(queueB,IPC_RMID,0);
msgctl(queueS,IPC_RMID,0);
}
