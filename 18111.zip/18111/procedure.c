#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include "header.h"

void Client(int queueB){
	Messaggio m;
	m.tipo=BALANCER;
	m.pid=getpid();
	for(int l=0;l<15;l++){
	msgsnd(queueB,(void*)&m,sizeof(Messaggio)-sizeof(long),0);
	printf("<C>Messaggio inviato dal client <%d> \n",m.pid);
	sleep(1);
	}
}

void Balancer(int queueB,int queueS){
	Messaggio m;
	while(1){
	//printf("<B> Aspetto..\n");
	msgrcv(queueB,&m,sizeof(Messaggio)-sizeof(long),BALANCER,0);
	//printf("<B> ha ricevuto il mex dal client <%d> \n",m.pid);	
	contatore++;
	m.tipo=(contatore%3 +1);
	//printf("<B>Il messaggio <%d> sarà inviato al server #%ld \n",m.pid,m.tipo );
	msgsnd(queueS,(void*)&m,sizeof(Messaggio)-sizeof(long),IPC_NOWAIT);
	//printf("<B> Messaggio inviato dal balancer <%ld > \n",m.pid);
	}
}

void Server(int queueS,int num_server){
	Messaggio m;
	while(1){
	msgrcv(queueS,(void*)&m,sizeof(Messaggio)-sizeof(long),num_server,0);
	printf("<S%d> Messaggio ricevuto dal client <%d> \n",num_server,m.pid);
	}
}


