#define BALANCER 1
#define NUM_CLIENT 8
#define NUM_SERVER 3

typedef struct {
	long tipo;
	int pid;
}Messaggio;

long contatore;

void Balancer(int,int);
void Server(int,int);
void Client(int);
