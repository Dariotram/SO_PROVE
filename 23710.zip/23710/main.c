#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "header.h"
#include "sys/wait.h"

int main(){
pid_t pid;
int status,queue1,queue2;
queue2=msgget(IPC_PRIVATE,IPC_CREAT|0664);
queue1=msgget(IPC_PRIVATE,IPC_CREAT|0664);
for(int i=0;i<5;i++){
	pid=fork();
	if(pid==0){
		Client(queue1);
	_exit(0);
	}
}
pid=fork();
if(pid==0){
	Server(queue1,queue2);
	_exit(0);
}
pid=fork();
if(pid==0){
	Printer(queue2);
	_exit(0);
}

for(int i=0;i<5;i++){
	pid=wait(&status);
	if(pid==-1)
		perror("errore\n");
	else
		printf("Il processo <%d> è terminato con stato: %d \n",pid,status);
}

msgctl(queue1,IPC_RMID,0);
msgctl(queue2,IPC_RMID,0);
}
