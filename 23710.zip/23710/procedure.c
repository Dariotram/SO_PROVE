#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "header.h"

static int queue2; 
static int queue1; 
void Client(int queue){
Messaggio m;
for(int k=0;k<15;k++){
	m.tipo=CLIENT;
	m.pid=getpid();
	msgsnd(queue,(void*)&m,sizeof(Messaggio)-sizeof(long),0);
	printf("<C> Messaggio inviato: %d \n",getpid() );
	sleep(1);
    }
}

void Server(int queue1,int queue2){
int i=0;
Messaggio m;
Messaggio buffer[10];
while(1){
msgrcv(queue1,(void*)&m,sizeof(Messaggio)-sizeof(long),CLIENT,0);

//printf("<S> Ho ricevuto il messaggio dal Client: %d, messaggio #%d\n",m.pid,i);
buffer[i].tipo=SERVER;
buffer[i].pid=m.pid;
i++;

	if(i==10){
		for(int k=0;k<10;k++){
		msgsnd(queue2,(void*)&buffer[k],sizeof(Messaggio)-sizeof(long),0);
		printf("<S> Messaggio inviato al printer \n" );
		}
		i=0;
		
	sleep(1);
	}
  }
}

void Printer(int queue){
Messaggio m;
int i=0;
while(1){

msgrcv(queue,(void*)&m,sizeof(Messaggio)-sizeof(long),SERVER,0);

//printf("<P> Ricevuto il messaggio dal server\n");
	printf("<P%i> Client: %d\n",i,m.pid);
	i++;
  }
}



