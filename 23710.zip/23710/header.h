#define CLIENT 1
#define SERVER 2
#define OK_TO_SEND 3
#define REQUEST_TO_SEND 4
typedef struct{
	long tipo;
	int pid;
}Messaggio;

void Client(int);
void Server(int,int);
void Printer(int);

